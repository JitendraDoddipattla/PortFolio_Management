﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Authentication.Models;
using Microsoft.Extensions.Configuration;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;

namespace Authentication.Repository
{

    public class AuthRepository : IAuthRepository
    {
        private IConfiguration _config;

  
        private readonly Dictionary<int, string> users = new Dictionary<int, string>() {
            { 12345,"admin1"},
            {789,"admin2" },
            {1729,"admin3" }
        };


        
        public AuthRepository(IConfiguration config)
        {
            _config = config;
        }



        public string GenerateToken(User user)
        {
            try
            {
                if (!users.Any(u => u.Key == user.PortFolioID && u.Value == user.Password))
                {
                    return null;
                }
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.ASCII.GetBytes(_config["Jwt:Key"]);
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(new Claim[]
                    {
                        new Claim(ClaimTypes.Name, user.PortFolioID.ToString())
                    }),
                    Expires = DateTime.UtcNow.AddHours(1),
                    SigningCredentials = new SigningCredentials(
                        new SymmetricSecurityKey(key),
                        SecurityAlgorithms.HmacSha256Signature)
                };
                var token = tokenHandler.CreateToken(tokenDescriptor);
                return tokenHandler.WriteToken(token);
            }
            catch (Exception exception)
            {
                return null;
            }

        }
    }
}
