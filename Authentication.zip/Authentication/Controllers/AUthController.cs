﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Authentication.Provider;
using Authentication.Models;

namespace Authentication.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthProvider _authProvider;

        public AuthController(IAuthProvider authProvider)
        {
            _authProvider = authProvider;
        }

      
        [HttpPost]
        public IActionResult AuthenticateUser(User user)
        {
            try
            {
                var token = _authProvider.AuthenticateUser(user);
                if (string.IsNullOrEmpty(token))
                {
                    return Unauthorized();
                }
                return Ok(new { tokenString = token });
            }
            catch (Exception)
            {
                return new StatusCodeResult(500);

            }
        }
    }
}
