﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Authentication.Models;
using Authentication.Repository;

namespace Authentication.Provider
{
    public class AuthProvider : IAuthProvider
    {
        private readonly IAuthRepository _authRepository;


       
        public AuthProvider(IAuthRepository authRepository)
        {
            _authRepository = authRepository;
        }


       
        public string AuthenticateUser(User user)
        {
            string token = null;
            try
            {
                token = _authRepository.GenerateToken(user);
            }
            catch (Exception exception)
            {
            }
            return token;
        }
    }
}
