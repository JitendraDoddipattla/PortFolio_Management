﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DailySharePrice.Models;

namespace DailySharePrice.Provider
{
    public interface IStockProvider
    {
        public Stock GetStockByNameProvider(string stockname);
    }
}
