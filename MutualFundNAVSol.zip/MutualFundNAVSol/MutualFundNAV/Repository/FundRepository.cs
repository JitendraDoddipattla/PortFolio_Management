﻿using MutualFundNAV.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace MutualFundNAV.Repository
{
    public class FundRepository : IFundRepository
    {
        private static List<Details> ListofFunds = new List<Details>() {
            new Details { FundId = 1, FundName = "UDAAN", FundValue = 135.84},
            new Details { FundId = 2, FundName = "VIVA", FundValue = 100.14},
            new Details { FundId = 2, FundName = "CRED", FundValue = 104.14}

        };

       

        public Details GetFundByNameRepository(string FundName)
{
    Details FundData = null;
    try
    {
        string fundName = FundName.ToUpper();
       FundData = ListofFunds.Where(e => e.FundName == fundName).FirstOrDefault();
        if (FundData != null)
        {
            var jsonFund = JsonConvert.SerializeObject(FundData);
        }
        else
        {
        }
    }
    catch (Exception)
            {
    }
    return FundData;
}

    }

}
