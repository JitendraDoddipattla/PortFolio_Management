﻿using MutualFundNAV.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFundNAV.Repository
{
   public interface IFundRepository
    {
        public Details GetFundByNameRepository(String FUndName);
    }
}
