﻿using Microsoft.AspNetCore.Mvc;
using MutualFundNAV.Provider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MutualFundNAV.Models;
using MutualFundNAV.Repository;
using Microsoft.OpenApi.Models;

namespace MutualFundNAV.Controllers
{
    [Route("api/[controller]")]
    [ApiController]


    public class FundNAVController : ControllerBase
    {
        private readonly IFundProvider FundProvider;

        public FundNAVController(IFundProvider _FundProvider)
        {
            FundProvider = _FundProvider;
        }
        [HttpGet("{FundName}")]
        public IActionResult GetFundDetailsByName( string FundName)
        {
            try
            {
                if (string.IsNullOrEmpty(FundName))
                {
                    return BadRequest( "Name cannot be null ");
                }
                var FundData=FundProvider.GetFundByNameProvider(FundName);
                if (FundData == null)
                {
                    return NotFound("Invalid Fund Name");
                }
                else
                {
                    return Ok(FundData);
                }
            }
            catch (Exception exception){
                return new StatusCodeResult(500);
            }
        }

        private void GetFundByNameProvider(string v, object fundName)
        {
            throw new NotImplementedException();
        }
    }
}
