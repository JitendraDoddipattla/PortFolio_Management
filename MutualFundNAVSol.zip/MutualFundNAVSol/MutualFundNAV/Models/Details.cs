﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFundNAV.Models
{
    public class Details
    {
        public int FundId { get; set; }
        public string FundName { get; set; }
        public double FundValue { get; set; }
    }
}
