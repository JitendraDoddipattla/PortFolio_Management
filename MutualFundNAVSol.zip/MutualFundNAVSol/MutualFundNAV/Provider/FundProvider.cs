﻿using MutualFundNAV.Models;
using MutualFundNAV.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFundNAV.Provider
{
    public class FundProvider:IFundProvider
    {
        private readonly IFundRepository FundRepository;
        public FundProvider(IFundRepository _FundRepository)
        {
            FundRepository = _FundRepository;
        }


        public Details GetFundByNameProvider(string FundName)
        {
            Details FundData = null;
            try
            {
                FundData = FundRepository.GetFundByNameRepository(FundName);
            }

            catch (Exception)
            {
            }
            return FundData;
        }
    }
    }

