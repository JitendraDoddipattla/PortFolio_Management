import React ,{useState} from "react";
import { useNavigate } from 'react-router-dom';
import './Receipt.css';


function Receipt()
{
    const navigate = useNavigate();
    function OnSubmit()
    {
        navigate("/Details");
    }
    function OnSubmit1()
    {
        localStorage.clear();
        navigate("/");
    }


    return(
        <>
        <div class="">

            <ul>
            <li><h2> Reciept</h2></li>
            <li class="Logout"><a class="active" href="/" onClick={() => OnSubmit1()}>LogOut</a></li>

            </ul>
            </div>
            <br/>
            <div class="">
            
            <label for="salestatus">Sale Status:</label><br/>
            <input type="text" id="salestatus" name="salestatus"></input><br/>
            <label for="newnetworth">New Networth:</label><br/>
            <input type="text" id="newnetworth" name="newnetworth"></input><br/><br/>
            
            </div>
            <br/>
            <button class="button button1" onClick={() => OnSubmit()}>Back to List</button>
        </>
    );
}
export default Receipt;