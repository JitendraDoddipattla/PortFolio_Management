import React,{useState} from 'react';
import { useNavigate } from "react-router-dom";
import './Login.css';


const  Login=()=>{
    const[id,setId]=useState("");
    const[password,setPassword]=useState("");
    const navigate = useNavigate();

    const handleIdChange=(value)=>{
        setId(value);
    }
    const handlePasswordChange=(value)=>{
        setPassword(value);
    }
    async function handleSubmit(e) {
        
        e.preventDefault();
        let postData = { id, password };
        let result = await fetch("https://localhost:44366/api/Auth", {
            method: "POST",
            headers: new Headers({
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify(postData)
        })
        .then(response => response.json())
            .then(data => {
                if (data.status == 404 ) {
                    alert("Wrong UserName or Pasword");
                    localStorage.clear();
                    window.location.reload();
                }
                
                localStorage.setItem("user-info", JSON.stringify(data));
                navigate("/Details");
                
            });
        

    }

    return(
        <>
        <h1>Login</h1>
        <center>
            <table>
                <tr>
                <td>Portfolio Id:</td>
                <td>
                    <input 
                        type="number" 
                        placeholder='enter id' 
                        id="id"
                        onChange={(e)=>handleIdChange(e.target.value)}>
                    </input> 
                </td>
                </tr>
                <tr>
                <td>Password:</td>
                <td>
                    <input 
                        type="password" 
                        id="password"
                        placeholder='enter password' 
                        onChange={(e)=>handlePasswordChange(e.target.value)}>
                    </input> 
                </td>
                </tr>
                <tr>
                    <button 
                        type="submit" 
                        value="Submit" 
                        class = "loginButton"
                        onClick={(e)=>handleSubmit(e)} >Login</button>
                </tr>
                
                
            </table>
            </center>
        </>
        
    );
}

export default Login;