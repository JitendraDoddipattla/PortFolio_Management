import React,{useState} from "react";
import { useNavigate } from 'react-router-dom';


function Details()
{
    const [getResult, setGetResult] = useState(null);

    const portfolioId = React.createRef();
    const navigate = useNavigate();
    const [getBool,setBool] = useState(false);

   

    async function OnSubmit() {
        navigate("/SellStock");
        const PortfolioId = portfolioId.current.value;
        
        await fetch(`https://localhost:44375/api/NetWorth/GetPortFolioDetailsByID/${PortfolioId}`)
            .then(response => response.json())
            .then(
                (result) => {
                  console.log(result); 
                    setGetResult([result]);
                    setBool(true);

                },
                (error) => {
                    alert("Some Error Occured During Fetching");
                    window.location.reload();
                }
            )
            
            };
            

    return(
        <>
        <h1>PortfolioDetails</h1>
        
        
            <div>
                <label htmlFor="PortfolioId" className="label">Portfolio Id : </label>
                <input type="number"  name="PortfolioId" ref={portfolioId} placeholder="PortfolioId" />
                <button type="button" onClick={() => OnSubmit()} className="btn btn-success">Submit</button>
            </div>
               <h2>Portfolio Id : 12345 </h2>
               <h2>NetWorth : $1500</h2>        
            
                
            <h2>Stock List</h2>
            <table  border={1} className="table table table-striped" style={{ "width": "50%", marginLeft: 250 }}>
                <thead >
                    <tr>
                        <th>Stock Name</th>
                        <th>Stock Price</th>
                        <th>Stock Count</th>
                        <th>Sell</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>eth</td>
                        <td>$100</td>
                        <td>10</td>
                        <td>
                            4

                        </td>
                    </tr> 
                    <tr>
                        <td>btc</td>
                        <td>$500</td>
                        <td>25</td>
                        <td>
                            1

                        </td>
                    </tr> 
                </tbody>
            </table>

            <h2>MutualFund List</h2>
            <table border={1} className="table table table-striped" style={{ "width": "50%", marginLeft: 250 }}>
                <thead >
                    <tr>
                        <th>MutualFund Name</th>
                        <th>MutualFund Price</th>
                        <th>MutualFund Count</th>
                        <th>Sell</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>UDAAN</td>
                        <td>150</td>
                        <td>18</td>
                        <td>
                            2

                        </td>
                    </tr> 
                </tbody>
            </table>
                

            
                
        
            
            </>
    );

}
export default Details;