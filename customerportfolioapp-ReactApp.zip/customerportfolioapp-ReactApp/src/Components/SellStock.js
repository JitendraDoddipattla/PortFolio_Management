import React,{useState} from "react";
import { useNavigate } from "react-router-dom";
import './SellStock.css';

function SellStock()
{
    const [getResult, setGetResult] = useState(null);
    const [getBool,setBool] = useState(false);

    const portfolioId = React.createRef();
    const navigate = useNavigate();      
            


    function OnSubmit()
    {
        navigate("/Receipt");
    }
    function OnSubmit1()
    {
        localStorage.clear();
        navigate("/");
    }
    return(
        <>
        <div>
         <ul>  
         <li> <h1>Sell your stock </h1></li>
         <li class="Logout"><a class="active" href="/" onClick={() => OnSubmit1()}>LoGOut</a> </li>

        </ul><br/>

        <br/>


          <label for="stockname">Stock Name:</label><br/>
          
          <input type="text" id="stockname" name="stockname" ></input><br/>
          <br/>
          <label for="stockcount">Stock Count:</label><br/>
          <input type="number" id="stockcount" name="stockcount" ></input>
        </div>
        <br/>
        <button class="button button1" onClick={() => OnSubmit()}>Sell</button>
        </>
    );
} 
export default SellStock;