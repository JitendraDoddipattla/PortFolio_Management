import React from 'react';

import './App.css';
import { Routes, Route } from 'react-router-dom';
import Login from './Components/Login';
import Details from './Components/Details';

import SellStock from './Components/SellStock';
import Receipt from './Components/Receipt';


function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/Details" element={<Details />} />
        <Route path="/SellStock" element={<SellStock />} />
        <Route path="/Receipt" element={<Receipt />} />
      </Routes>

    </div>
    
    

  );
}

export default App;
